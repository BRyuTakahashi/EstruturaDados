package org.example;

public interface Vendavel {

    // metodos

    public Double getPreco();
}
